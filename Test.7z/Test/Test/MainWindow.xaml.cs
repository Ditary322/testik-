﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Test
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int score = 0;

            if (v1_verno.IsChecked == true) score++;
            if (v2_verno.IsChecked == true) score++;
            if (v3_verno_1.IsChecked == true) score++;
            if (v3_verno_2.IsChecked == true) score++;
            if (v3_verno_3.IsChecked == true) score++;
            if (v4_verno.IsChecked == true) score++;
            if (v5_verno.IsChecked == true) score++;
            if (v6_verno_1.IsChecked == true) score++;
            if (v6_verno_2.IsChecked == true) score++;
            if (v6_verno_3.IsChecked == true) score++;
            if (v7_verno.IsChecked == true) score++;
            if (v8_verno.IsChecked == true) score++;
            if (v9_verno.IsChecked == true) score++;
            if (v10_verno.IsChecked == true) score++;
            if (v11_verno.IsChecked == true) score++;
            if (v12_verno.IsChecked == true) score++;
            if (v13_verno.IsChecked == true) score++;
            if (v14_verno.IsChecked == true) score++;
            if (v15_verno.IsChecked == true) score++;

            ResultText.Text = $"{score}";
        }
    }
}
